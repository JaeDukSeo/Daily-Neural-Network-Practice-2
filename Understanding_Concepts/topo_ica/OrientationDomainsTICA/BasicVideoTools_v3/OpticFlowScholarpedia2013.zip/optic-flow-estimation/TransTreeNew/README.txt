The translating tree sequence was produced by David Fleet.

For further information see
ftp.csd.uwo.ca/pub/vision/TESTDATA/README

and

Barron, J. Fleet, D., and Beauchemin, S. (1994). Performance 
of optical flow techniques. International Journal of Computer 
Vision 12, 43�77. 