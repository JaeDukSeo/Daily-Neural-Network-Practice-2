
This sequence is my own work and was generated with the ray tracer povray.
If you want further information about the geometry or ground-truth for depth
and flow please email me at 
florian.raudies__at__gmail__dot__com (Replace __at__ by @ and __dot__ by .).
